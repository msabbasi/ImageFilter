/** Automatically generated file. DO NOT MODIFY */
package com.mujda.imagefilter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}